﻿$(document).ready(function () {

    carregarImg();
   
});



function carregarImg() {
    $("#foto").attr("src", "/img/music.jpg");
    $("#foto").attr("alt", "Foto de Musica");
}

